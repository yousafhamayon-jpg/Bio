MOBILE 10X TRADER — v0.1 SOURCE BUILD
=====================================

WHAT THIS IS
------------
A mobile-only Android Binance USDⓈ-M Futures trading-agent prototype.

It does NOT use a paid AI API.
Instead, it uses a deterministic "10X" multi-factor engine so the analysis is free,
repeatable, inspectable, and less likely to hallucinate than an LLM.

DEFAULT MODE IS PAPER TRADING.
LIVE MODE IS PRESENT, but must be explicitly enabled and confirmed by typing LIVE.

THE 10 FACTORS
--------------
1. 4-hour trend
2. 1-hour trend
3. 15-minute entry trend
4. RSI + MACD momentum
5. Volume expansion
6. ADX / volatility quality
7. Open-interest sanity check
8. Funding-rate crowding
9. Global long/short crowding
10. BTC market regime alignment

UNIVERSE
--------
The app scans the top 50 most-liquid Binance USDT-M perpetual contracts by 24h quote volume.
It then does a cheaper first-stage scan, keeps the strongest 8, and performs the full
10-factor analysis on those. This reduces API load and phone battery use.

DEFAULT SAFETY SETTINGS
-----------------------
Bot capital: 10 USDT
Leverage: 3x maximum
Risk per trade: 1.5% of BOT CAPITAL
Daily loss stop: 5% of BOT CAPITAL
Maximum 3 losing trades per day
30-minute cooldown after a loss
One bot position at a time
Isolated margin only
No DCA
No martingale
Minimum reward:risk target: 2.2:1
Minimum score: 75/100
If Binance minimum order size would violate risk, the trade is SKIPPED.

IMPORTANT ABOUT YOUR 232 USDT
-----------------------------
The app's 10 USDT setting is a SOFTWARE HARD CAP used for its own sizing.
Binance itself does not create a separate 10 USDT sub-wallet inside the same Futures wallet.
For maximum isolation, keep only the amount you want the bot to risk in the Futures wallet
or use a separate Binance sub-account if your account supports that.

The app will:
- refuse Hedge Mode (requires One-way Mode)
- refuse to open on a symbol that already has a manual position
- use client order IDs beginning M10X
- attach a STOP and TAKE-PROFIT immediately after a live entry
- flatten the entry if either protective order cannot be attached

BINANCE API KEY SAFETY
----------------------
Create a dedicated API key for this bot.
Enable Futures trading only.
DO NOT ENABLE WITHDRAWALS.
Do not paste the secret into ChatGPT.
The app stores the key/secret encrypted with Android Keystore.

BACKGROUND OPERATION
--------------------
The bot runs as an Android foreground service and shows a persistent notification.
Start it from the app while the app is visible.
Android can still stop apps under unusual system/battery conditions.
The app asks you to exempt it from battery optimization after START.

CURRENT BINANCE API DESIGN
--------------------------
This build is aligned with the current Binance Futures API design researched in Sep 2026:
- market entry: POST /fapi/v1/order
- conditional STOP / TAKE PROFIT: POST /fapi/v1/algoOrder
Binance migrated conditional USD-M Futures orders to the Algo service in Dec 2025.

BUILD AN APK
------------
This ZIP is a complete Android Studio source project.

1. Install Android Studio on a Windows computer once.
2. Open the folder "Mobile10XTrader".
3. Let Gradle sync.
4. Build > Build APK(s).
5. Copy the generated APK to your Samsung phone and install it.
6. After that, normal bot use is phone-only.

The current project uses:
- Android Gradle Plugin 9.4.0
- compileSdk 36
- targetSdk 36
- minSdk 26
- Java 17
- no third-party runtime libraries

FIRST TEST
----------
1. Install the APK.
2. LEAVE "Live trading" OFF.
3. Bot capital = 10.
4. Press CHECK CONNECTION.
5. Press START BOT.
6. Let PAPER mode run first.
7. Review several signals/trades.
8. Only consider LIVE after the paper workflow is behaving correctly.

NO PROFIT GUARANTEE
-------------------
No bot, AI system, indicator set, or strategy can guarantee profit.
Futures can lose money quickly. The purpose of the safeguards is to limit damage,
not eliminate trading risk.
