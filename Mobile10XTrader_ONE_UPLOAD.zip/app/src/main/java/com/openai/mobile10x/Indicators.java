package com.openai.mobile10x;

import java.util.List;

public final class Indicators {
    private Indicators() {}

    public static double ema(List<Double> v, int period) {
        if (v == null || v.isEmpty()) return 0;
        double k = 2.0 / (period + 1.0);
        double e = v.get(0);
        for (int i = 1; i < v.size(); i++) e = v.get(i) * k + e * (1.0 - k);
        return e;
    }

    public static double rsi(List<Double> c, int period) {
        if (c == null || c.size() < period + 2) return 50;
        double gain = 0, loss = 0;
        int start = c.size() - period - 1;
        for (int i = start + 1; i < c.size(); i++) {
            double d = c.get(i) - c.get(i - 1);
            if (d > 0) gain += d; else loss -= d;
        }
        if (loss == 0) return 100;
        double rs = (gain / period) / (loss / period);
        return 100 - 100 / (1 + rs);
    }

    public static double atr(List<BinanceClient.Candle> k, int period) {
        if (k == null || k.size() < period + 2) return 0;
        double sum = 0;
        int start = k.size() - period;
        for (int i = start; i < k.size(); i++) {
            BinanceClient.Candle x = k.get(i);
            double prevClose = k.get(i - 1).close;
            double tr = Math.max(x.high - x.low,
                    Math.max(Math.abs(x.high - prevClose), Math.abs(x.low - prevClose)));
            sum += tr;
        }
        return sum / period;
    }

    public static double volumeRatio(List<BinanceClient.Candle> k, int lookback) {
        if (k == null || k.size() < lookback + 1) return 1;
        double avg = 0;
        for (int i = k.size() - lookback - 1; i < k.size() - 1; i++) avg += k.get(i).volume;
        avg /= lookback;
        return avg <= 0 ? 1 : k.get(k.size() - 1).volume / avg;
    }

    public static double macdHistogram(List<Double> c) {
        if (c == null || c.size() < 40) return 0;
        // Build approximate MACD series over the last 35 bars and EMA9 signal.
        java.util.ArrayList<Double> macd = new java.util.ArrayList<>();
        for (int end = Math.max(26, c.size() - 35); end <= c.size(); end++) {
            List<Double> sub = c.subList(0, end);
            macd.add(ema(sub, 12) - ema(sub, 26));
        }
        double m = macd.get(macd.size() - 1);
        double s = ema(macd, 9);
        return m - s;
    }

    public static double adx(List<BinanceClient.Candle> k, int period) {
        if (k == null || k.size() < period + 3) return 0;
        double trSum = 0, plus = 0, minus = 0;
        int start = k.size() - period;
        for (int i = start; i < k.size(); i++) {
            BinanceClient.Candle cur = k.get(i);
            BinanceClient.Candle prev = k.get(i - 1);
            double up = cur.high - prev.high;
            double down = prev.low - cur.low;
            plus += (up > down && up > 0) ? up : 0;
            minus += (down > up && down > 0) ? down : 0;
            trSum += Math.max(cur.high - cur.low,
                    Math.max(Math.abs(cur.high - prev.close), Math.abs(cur.low - prev.close)));
        }
        if (trSum == 0) return 0;
        double pdi = 100 * plus / trSum;
        double mdi = 100 * minus / trSum;
        return (pdi + mdi == 0) ? 0 : 100 * Math.abs(pdi - mdi) / (pdi + mdi);
    }

    public static double swingLow(List<BinanceClient.Candle> k, int bars) {
        double x = Double.MAX_VALUE;
        for (int i = Math.max(0, k.size() - bars); i < k.size(); i++) x = Math.min(x, k.get(i).low);
        return x;
    }

    public static double swingHigh(List<BinanceClient.Candle> k, int bars) {
        double x = -Double.MAX_VALUE;
        for (int i = Math.max(0, k.size() - bars); i < k.size(); i++) x = Math.max(x, k.get(i).high);
        return x;
    }
}
