package com.openai.mobile10x;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public class TradeManager {
    private final BinanceClient api;
    private final BotSettings settings;
    private final BotService.LogSink log;

    public TradeManager(BinanceClient api, BotSettings settings, BotService.LogSink log) {
        this.api=api; this.settings=settings; this.log=log;
    }

    public boolean dailyRiskAllows() {
        double maxLoss = settings.capital() * settings.dailyLossPct()/100.0;
        if (settings.dailyPnl() <= -maxLoss) {
            log.log("NO TRADE: daily loss stop reached.");
            return false;
        }
        if (settings.lossCount() >= 3) {
            log.log("NO TRADE: 3 losing trades today.");
            return false;
        }
        if (settings.lastLossTime() > 0 &&
                System.currentTimeMillis() - settings.lastLossTime() < 30*60*1000L) {
            log.log("NO TRADE: 30-minute cooldown after loss.");
            return false;
        }
        return true;
    }

    public void monitorActive() throws Exception {
        if (!settings.hasActiveTrade()) return;
        String symbol = settings.activeSymbol();
        String side = settings.activeSide();

        if (settings.activePaper()) {
            double p = api.lastPrice(symbol);
            boolean stop = side.equals("LONG") ? p <= settings.activeStop() : p >= settings.activeStop();
            boolean tp = side.equals("LONG") ? p >= settings.activeTarget() : p <= settings.activeTarget();
            if (stop || tp) {
                double pnl = side.equals("LONG")
                        ? settings.activeQty()*(p-settings.activeEntry())
                        : settings.activeQty()*(settings.activeEntry()-p);
                settings.recordPnl(pnl);
                if (pnl < 0) settings.markLossTime();
                log.log("PAPER CLOSED " + symbol + " PnL=" + money(pnl));
                settings.clearActiveTrade();
            }
            return;
        }

        BinanceClient.Position p = api.positionFor(symbol);
        if (p == null || Math.abs(p.amount) < 1e-12) {
            api.cancelAlgo(settings.activeSlId());
            api.cancelAlgo(settings.activeTpId());
            log.log("LIVE position closed at Binance. Protection siblings cleaned.");
            settings.clearActiveTrade();
        }
    }

    public void open(SignalEngine.Signal s, Map<String,BinanceClient.SymbolRules> rules) throws Exception {
        if (settings.hasActiveTrade()) throw new Exception("Bot already has an active trade.");
        if (!dailyRiskAllows()) return;

        BinanceClient.SymbolRules r = rules.get(s.symbol);
        if (r == null) throw new Exception("Missing symbol trading rules.");

        double riskUsdt = settings.capital() * settings.riskPct()/100.0;
        double notionalByRisk = riskUsdt / s.stopPct;
        double maxNotionalByCapital = settings.capital() * settings.leverage() * 0.70;
        double notional = Math.min(notionalByRisk, maxNotionalByCapital);

        if (notional < r.minNotional) {
            // Never increase risk just to satisfy exchange minimum.
            throw new Exception("Skip: exchange minimum notional would exceed configured risk.");
        }

        double qty = BinanceClient.floorStep(notional / s.entry, r.stepSize);
        if (qty < r.minQty || qty <= 0) throw new Exception("Skip: quantity below Binance minimum.");

        if (!settings.live()) {
            settings.setActiveTrade(
                    s.symbol, s.side, qty, s.entry, s.stop, s.target,
                    "", "", true);
            log.log("PAPER OPEN " + s.side + " " + s.symbol +
                    " qty=" + BinanceClient.fmt(qty) +
                    " entry=" + BinanceClient.fmt(s.entry) +
                    " SL=" + BinanceClient.fmt(s.stop) +
                    " TP=" + BinanceClient.fmt(s.target));
            return;
        }

        api.syncTime();
        if (api.hedgeMode()) throw new Exception("LIVE blocked: Binance Hedge Mode is ON. Use One-way Mode for this bot.");

        double available = api.usdtAvailableBalance();
        double requiredMargin = notional / settings.leverage();
        if (requiredMargin > settings.capital() + 1e-9)
            throw new Exception("Hard bot-capital check failed.");
        if (requiredMargin > available)
            throw new Exception("Not enough available Futures balance.");

        // Never mix with an existing manual position on the target symbol.
        BinanceClient.Position existing = api.positionFor(s.symbol);
        if (existing != null && Math.abs(existing.amount) > 1e-12)
            throw new Exception("LIVE blocked: an existing manual position is open on " + s.symbol);

        api.setIsolated(s.symbol);
        api.setLeverage(s.symbol, settings.leverage());

        String stamp = String.valueOf(System.currentTimeMillis()%1_000_000_000L);
        String entryId = "M10X_" + stamp;
        String slId = "M10XSL_" + stamp;
        String tpId = "M10XTP_" + stamp;
        String entrySide = s.side.equals("LONG") ? "BUY" : "SELL";
        String exitSide = s.side.equals("LONG") ? "SELL" : "BUY";

        JSONObject fill = api.marketOrder(s.symbol, entrySide, qty, entryId);
        double avg = fill.optDouble("avgPrice", 0);
        if (avg <= 0) avg = s.entry;

        try {
            api.algoClose(s.symbol, exitSide, "STOP_MARKET", s.stop, slId);
        } catch (Exception protectionError) {
            // Fail closed: if no stop can be attached, flatten immediately.
            api.reduceOnlyMarket(s.symbol, exitSide, qty, "M10XFAIL_" + stamp);
            throw new Exception("Entry flattened because STOP placement failed: " + protectionError.getMessage());
        }

        try {
            api.algoClose(s.symbol, exitSide, "TAKE_PROFIT_MARKET", s.target, tpId);
        } catch (Exception tpError) {
            api.cancelAlgo(slId);
            api.reduceOnlyMarket(s.symbol, exitSide, qty, "M10XFAIL2_" + stamp);
            throw new Exception("Entry flattened because TP placement failed: " + tpError.getMessage());
        }

        settings.setActiveTrade(s.symbol, s.side, qty, avg, s.stop, s.target, slId, tpId, false);
        log.log("LIVE OPEN " + s.side + " " + s.symbol +
                " qty=" + BinanceClient.fmt(qty) +
                " margin<=" + money(requiredMargin) +
                " SL/TP attached.");
    }

    public void emergencyClose() throws Exception {
        if (!settings.hasActiveTrade()) {
            log.log("Emergency close: no bot trade stored.");
            return;
        }

        if (settings.activePaper()) {
            double p = api.lastPrice(settings.activeSymbol());
            double pnl = settings.activeSide().equals("LONG")
                    ? settings.activeQty()*(p-settings.activeEntry())
                    : settings.activeQty()*(settings.activeEntry()-p);
            settings.recordPnl(pnl);
            if (pnl < 0) settings.markLossTime();
            settings.clearActiveTrade();
            log.log("PAPER emergency closed. PnL=" + money(pnl));
            return;
        }

        api.syncTime();
        String exitSide = settings.activeSide().equals("LONG") ? "SELL" : "BUY";
        api.cancelAlgo(settings.activeSlId());
        api.cancelAlgo(settings.activeTpId());
        api.reduceOnlyMarket(
                settings.activeSymbol(), exitSide, settings.activeQty(),
                "M10XEMG_" + (System.currentTimeMillis()%1_000_000_000L));
        settings.clearActiveTrade();
        log.log("LIVE emergency close sent.");
    }

    private static String money(double x) {
        return String.format(Locale.US, "%.4f USDT", x);
    }
}
