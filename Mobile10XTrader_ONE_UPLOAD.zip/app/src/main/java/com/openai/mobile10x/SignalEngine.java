package com.openai.mobile10x;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class SignalEngine {
    public static class Signal {
        public String symbol;
        public String side; // LONG / SHORT
        public int score;
        public double entry, stop, target, stopPct;
        public String explanation;
    }

    private final BinanceClient api;

    public SignalEngine(BinanceClient api) {
        this.api = api;
    }

    private static List<Double> closes(List<BinanceClient.Candle> k) {
        ArrayList<Double> c = new ArrayList<>();
        for (BinanceClient.Candle x : k) c.add(x.close);
        return c;
    }

    private static int dir(double x, double deadband) {
        if (x > deadband) return 1;
        if (x < -deadband) return -1;
        return 0;
    }

    public Signal scan(Map<String,BinanceClient.SymbolRules> rules, int minScore,
                       BotService.LogSink log) throws Exception {
        List<String> symbols = api.top50LiquidSymbols(rules);
        log.log("Universe: top 50 liquid USDT-M perpetuals.");

        // BTC regime is a hard context factor for every alt.
        List<BinanceClient.Candle> btc1h = api.klines("BTCUSDT", "1h", 220);
        List<BinanceClient.Candle> btc4h = api.klines("BTCUSDT", "4h", 220);
        int btcDir = trendDirection(btc1h, 20, 50) + trendDirection(btc4h, 50, 200);
        btcDir = Integer.compare(btcDir, 0);

        // Stage 1: cheap pre-ranking. This avoids doing expensive 10-factor work on all 50.
        class Pre {
            String s; double score;
            Pre(String s,double score){this.s=s;this.score=score;}
        }
        ArrayList<Pre> pre = new ArrayList<>();
        for (String s : symbols) {
            try {
                List<BinanceClient.Candle> m15 = api.klines(s, "15m", 120);
                List<BinanceClient.Candle> h1 = api.klines(s, "1h", 120);
                List<Double> c15 = closes(m15), c1 = closes(h1);
                double p = 0;
                p += 25 * dir(Indicators.ema(c15,20)/Indicators.ema(c15,50)-1, 0.0015);
                p += 35 * dir(Indicators.ema(c1,20)/Indicators.ema(c1,50)-1, 0.0020);
                double r = Indicators.rsi(c15,14);
                p += (r > 55 ? 12 : r < 45 ? -12 : 0);
                p += 8 * dir(Indicators.macdHistogram(c15), Math.max(1e-12, c15.get(c15.size()-1)*0.00002));
                double vr = Indicators.volumeRatio(m15,20);
                p *= Math.min(1.25, Math.max(0.8, vr));
                pre.add(new Pre(s,p));
            } catch (Exception ignored) {}
        }
        pre.sort((a,b) -> Double.compare(Math.abs(b.score), Math.abs(a.score)));
        if (pre.size() > 8) pre = new ArrayList<>(pre.subList(0,8));

        Signal best = null;

        for (Pre pr : pre) {
            try {
                Signal s = fullScore(pr.s, btcDir);
                log.log(pr.s + " 10X score=" + s.score + " " + s.side);
                if (Math.abs(s.score) >= minScore &&
                        (best == null || Math.abs(s.score) > Math.abs(best.score))) {
                    best = s;
                }
            } catch (Exception e) {
                log.log(pr.s + " skipped: " + e.getMessage());
            }
        }
        return best;
    }

    private int trendDirection(List<BinanceClient.Candle> k, int fast, int slow) {
        List<Double> c = closes(k);
        double f = Indicators.ema(c,fast), s = Indicators.ema(c,slow);
        return f > s ? 1 : f < s ? -1 : 0;
    }

    private Signal fullScore(String symbol, int btcDir) throws Exception {
        List<BinanceClient.Candle> m15 = api.klines(symbol, "15m", 220);
        List<BinanceClient.Candle> h1 = api.klines(symbol, "1h", 220);
        List<BinanceClient.Candle> h4 = api.klines(symbol, "4h", 220);
        List<Double> c15 = closes(m15), c1 = closes(h1), c4 = closes(h4);

        double price = c15.get(c15.size()-1);
        int score = 0;
        StringBuilder why = new StringBuilder();

        // 1) 4h trend: 16
        int t4 = trendDirection(h4,50,200);
        score += 16*t4; why.append("4h trend ").append(t4).append("; ");

        // 2) 1h trend: 14
        int t1 = trendDirection(h1,20,50);
        score += 14*t1; why.append("1h trend ").append(t1).append("; ");

        // 3) 15m entry trend: 10
        int t15 = trendDirection(m15,20,50);
        score += 10*t15; why.append("15m trend ").append(t15).append("; ");

        // Require higher timeframes to agree. If not, confidence collapses.
        if (t4 != 0 && t1 != 0 && t4 != t1) score = score / 2;

        // 4) Momentum RSI + MACD: 12
        double rsi = Indicators.rsi(c15,14);
        double mh = Indicators.macdHistogram(c15);
        int mom = 0;
        if (rsi >= 54 && rsi <= 72) mom++;
        if (rsi <= 46 && rsi >= 28) mom--;
        if (mh > 0) mom++; else if (mh < 0) mom--;
        score += 6 * Integer.compare(mom,0);
        why.append("RSI ").append((int)rsi).append("; ");

        // 5) Volume expansion: 8
        double vr = Indicators.volumeRatio(m15,20);
        int likely = Integer.compare(score,0);
        if (vr >= 1.15) score += 8*likely;
        else if (vr < 0.7) score -= 4*likely;
        why.append("vol x").append(String.format(java.util.Locale.US,"%.2f",vr)).append("; ");

        // 6) Volatility/ADX: 8
        double adx = Indicators.adx(h1,14);
        if (adx >= 22) score += 8*Integer.compare(score,0);
        else if (adx < 15) score -= 6*Integer.compare(score,0);
        why.append("ADX ").append((int)adx).append("; ");

        // 7) Open-interest confirmation: 8.
        // We use current OI as a liquidity sanity check, not as a directional oracle.
        double oi = api.openInterest(symbol);
        if (oi > 0) score += 8*Integer.compare(score,0);

        // 8) Funding contrarian/crowding: 8
        double funding = api.fundingRate(symbol);
        int d = Integer.compare(score,0);
        if (d > 0 && funding > 0.0010) score -= 8;
        else if (d < 0 && funding < -0.0010) score += 8;
        else score += 4*d;
        why.append("fund ").append(String.format(java.util.Locale.US,"%.4f%%",funding*100)).append("; ");

        // 9) Long/short crowding: 8
        double lsr = api.globalLongShortRatio(symbol);
        if (d > 0 && lsr > 1.8) score -= 8;
        else if (d < 0 && lsr < 0.56) score += 8;
        else score += 4*d;
        why.append("L/S ").append(String.format(java.util.Locale.US,"%.2f",lsr)).append("; ");

        // 10) BTC regime alignment: 8
        if ("BTCUSDT".equals(symbol) || btcDir == 0) score += 4*d;
        else if (d == btcDir) score += 8*d;
        else score -= 8*d;
        why.append("BTC regime ").append(btcDir).append("; ");

        score = Math.max(-100, Math.min(100, score));
        String side = score >= 0 ? "LONG" : "SHORT";

        // Risk geometry: swing + ATR, bounded to avoid tiny/noisy or huge stops.
        double atr = Indicators.atr(m15,14);
        double swing = side.equals("LONG") ? Indicators.swingLow(m15,12) : Indicators.swingHigh(m15,12);
        double atrStop = side.equals("LONG") ? price - 1.25*atr : price + 1.25*atr;
        double rawStop = side.equals("LONG") ? Math.min(atrStop, swing) : Math.max(atrStop, swing);
        double stopPct = Math.abs(price-rawStop)/price;
        stopPct = Math.max(0.006, Math.min(0.025, stopPct));
        double stop = side.equals("LONG") ? price*(1-stopPct) : price*(1+stopPct);
        double rr = 2.2;
        double target = side.equals("LONG") ? price*(1+rr*stopPct) : price*(1-rr*stopPct);

        Signal out = new Signal();
        out.symbol=symbol; out.side=side; out.score=score;
        out.entry=price; out.stop=stop; out.target=target; out.stopPct=stopPct;
        out.explanation=why.toString();
        return out;
    }
}
