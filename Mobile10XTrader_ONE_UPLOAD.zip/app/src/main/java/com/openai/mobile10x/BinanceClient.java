package com.openai.mobile10x;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class BinanceClient {
    public static final String BASE = "https://fapi.binance.com";
    private final String apiKey;
    private final String secret;
    private long timeOffset = 0;

    public BinanceClient(String apiKey, String secret) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.secret = secret == null ? "" : secret.trim();
    }

    public static class Candle {
        public double open, high, low, close, volume;
        public Candle(double o, double h, double l, double c, double v) {
            open=o; high=h; low=l; close=c; volume=v;
        }
    }

    public static class SymbolRules {
        public String symbol;
        public double stepSize = 0.001;
        public double minQty = 0;
        public double minNotional = 5;
        public double tickSize = 0.01;
        public int pricePrecision = 2;
        public int qtyPrecision = 3;
    }

    public static class Position {
        public String symbol;
        public double amount, entryPrice, unrealizedPnl;
    }

    private static String read(InputStream is) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    private String request(String method, String path, Map<String,String> params,
                           boolean signed) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        if (params != null) p.putAll(params);
        if (signed) {
            if (apiKey.isEmpty() || secret.isEmpty()) throw new Exception("API key/secret missing.");
            p.put("timestamp", String.valueOf(System.currentTimeMillis() + timeOffset));
            p.put("recvWindow", "5000");
        }

        StringBuilder q = new StringBuilder();
        for (Map.Entry<String,String> e : p.entrySet()) {
            if (q.length() > 0) q.append("&");
            q.append(URLEncoder.encode(e.getKey(), "UTF-8"))
             .append("=")
             .append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        if (signed) {
            q.append("&signature=").append(hmac(q.toString(), secret));
        }

        String url = BASE + path;
        boolean body = method.equals("POST") || method.equals("PUT") || method.equals("DELETE");
        if (!body && q.length() > 0) url += "?" + q;

        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Accept", "application/json");
        if (!apiKey.isEmpty()) c.setRequestProperty("X-MBX-APIKEY", apiKey);

        if (body) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            try (OutputStream os = c.getOutputStream()) {
                os.write(q.toString().getBytes(StandardCharsets.UTF_8));
            }
        }

        int code = c.getResponseCode();
        String text = read(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) {
            throw new Exception("Binance HTTP " + code + ": " + text);
        }
        return text;
    }

    private static String hmac(String data, String secret) throws Exception {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] out = m.doFinal(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder();
        for (byte b : out) s.append(String.format(Locale.US, "%02x", b & 0xff));
        return s.toString();
    }

    public void syncTime() throws Exception {
        JSONObject o = new JSONObject(request("GET", "/fapi/v1/time", null, false));
        timeOffset = o.getLong("serverTime") - System.currentTimeMillis();
    }

    public List<Candle> klines(String symbol, String interval, int limit) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("interval", interval);
        p.put("limit", String.valueOf(limit));
        JSONArray a = new JSONArray(request("GET", "/fapi/v1/klines", p, false));
        ArrayList<Candle> out = new ArrayList<>();
        for (int i=0;i<a.length();i++) {
            JSONArray x = a.getJSONArray(i);
            out.add(new Candle(
                    x.getDouble(1), x.getDouble(2), x.getDouble(3),
                    x.getDouble(4), x.getDouble(5)));
        }
        return out;
    }

    public double lastPrice(String symbol) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        JSONObject o = new JSONObject(request("GET", "/fapi/v1/ticker/price", p, false));
        return o.getDouble("price");
    }

    public double fundingRate(String symbol) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        JSONObject o = new JSONObject(request("GET", "/fapi/v1/premiumIndex", p, false));
        return o.optDouble("lastFundingRate", 0);
    }

    public double openInterest(String symbol) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        JSONObject o = new JSONObject(request("GET", "/fapi/v1/openInterest", p, false));
        return o.optDouble("openInterest", 0);
    }

    public double globalLongShortRatio(String symbol) {
        try {
            String url = "https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=" +
                    URLEncoder.encode(symbol, "UTF-8") + "&period=15m&limit=1";
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(12000);
            JSONArray a = new JSONArray(read(c.getInputStream()));
            if (a.length() == 0) return 1;
            return a.getJSONObject(a.length()-1).optDouble("longShortRatio", 1);
        } catch (Exception e) {
            return 1;
        }
    }

    public Map<String,SymbolRules> exchangeRules() throws Exception {
        JSONObject o = new JSONObject(request("GET", "/fapi/v1/exchangeInfo", null, false));
        JSONArray s = o.getJSONArray("symbols");
        HashMap<String,SymbolRules> map = new HashMap<>();
        for (int i=0;i<s.length();i++) {
            JSONObject x = s.getJSONObject(i);
            if (!"TRADING".equals(x.optString("status"))) continue;
            if (!"USDT".equals(x.optString("quoteAsset"))) continue;
            if (!"PERPETUAL".equals(x.optString("contractType"))) continue;

            SymbolRules r = new SymbolRules();
            r.symbol = x.getString("symbol");
            r.pricePrecision = x.optInt("pricePrecision", 2);
            r.qtyPrecision = x.optInt("quantityPrecision", 3);

            JSONArray f = x.getJSONArray("filters");
            for (int j=0;j<f.length();j++) {
                JSONObject z = f.getJSONObject(j);
                String type = z.optString("filterType");
                if ("PRICE_FILTER".equals(type)) r.tickSize = z.optDouble("tickSize", r.tickSize);
                if ("LOT_SIZE".equals(type)) {
                    r.stepSize = z.optDouble("stepSize", r.stepSize);
                    r.minQty = z.optDouble("minQty", r.minQty);
                }
                if ("MARKET_LOT_SIZE".equals(type) && z.optDouble("stepSize", 0) > 0) {
                    r.stepSize = z.optDouble("stepSize", r.stepSize);
                    r.minQty = Math.max(r.minQty, z.optDouble("minQty", 0));
                }
                if ("MIN_NOTIONAL".equals(type) || "NOTIONAL".equals(type)) {
                    r.minNotional = z.optDouble("notional",
                            z.optDouble("minNotional", r.minNotional));
                }
            }
            map.put(r.symbol, r);
        }
        return map;
    }

    public List<String> top50LiquidSymbols(Map<String,SymbolRules> rules) throws Exception {
        JSONArray a = new JSONArray(request("GET", "/fapi/v1/ticker/24hr", null, false));
        ArrayList<JSONObject> rows = new ArrayList<>();
        for (int i=0;i<a.length();i++) {
            JSONObject x = a.getJSONObject(i);
            if (rules.containsKey(x.optString("symbol"))) rows.add(x);
        }
        rows.sort((a1, b1) -> Double.compare(b1.optDouble("quoteVolume",0), a1.optDouble("quoteVolume",0)));
        ArrayList<String> out = new ArrayList<>();
        for (JSONObject x : rows) {
            String sym = x.optString("symbol");
            // Avoid stablecoin-vs-stablecoin style contracts if any appear.
            if (sym.startsWith("USDC") || sym.startsWith("FDUSD") || sym.startsWith("USDP")) continue;
            out.add(sym);
            if (out.size() >= 50) break;
        }
        return out;
    }

    public boolean hedgeMode() throws Exception {
        JSONObject o = new JSONObject(request("GET", "/fapi/v1/positionSide/dual", null, true));
        return o.optBoolean("dualSidePosition", false);
    }

    public double usdtAvailableBalance() throws Exception {
        JSONArray a = new JSONArray(request("GET", "/fapi/v3/balance", null, true));
        for (int i=0;i<a.length();i++) {
            JSONObject x = a.getJSONObject(i);
            if ("USDT".equals(x.optString("asset"))) return x.optDouble("availableBalance", 0);
        }
        return 0;
    }

    public List<Position> positions() throws Exception {
        JSONArray a = new JSONArray(request("GET", "/fapi/v3/positionRisk", null, true));
        ArrayList<Position> out = new ArrayList<>();
        for (int i=0;i<a.length();i++) {
            JSONObject x = a.getJSONObject(i);
            double amt = x.optDouble("positionAmt", 0);
            if (Math.abs(amt) < 1e-12) continue;
            Position p = new Position();
            p.symbol = x.optString("symbol");
            p.amount = amt;
            p.entryPrice = x.optDouble("entryPrice", 0);
            p.unrealizedPnl = x.optDouble("unRealizedProfit", x.optDouble("unrealizedProfit", 0));
            out.add(p);
        }
        return out;
    }

    public Position positionFor(String symbol) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        JSONArray a = new JSONArray(request("GET", "/fapi/v3/positionRisk", p, true));
        if (a.length() == 0) return null;
        JSONObject x = a.getJSONObject(0);
        Position pos = new Position();
        pos.symbol = symbol;
        pos.amount = x.optDouble("positionAmt", 0);
        pos.entryPrice = x.optDouble("entryPrice", 0);
        pos.unrealizedPnl = x.optDouble("unRealizedProfit", x.optDouble("unrealizedProfit", 0));
        return pos;
    }

    public void setIsolated(String symbol) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol); p.put("marginType", "ISOLATED");
        try {
            request("POST", "/fapi/v1/marginType", p, true);
        } catch (Exception e) {
            if (!e.getMessage().contains("-4046")) throw e; // already isolated
        }
    }

    public void setLeverage(String symbol, int leverage) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol); p.put("leverage", String.valueOf(leverage));
        request("POST", "/fapi/v1/leverage", p, true);
    }

    public JSONObject marketOrder(String symbol, String side, double qty, String clientId) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", side);
        p.put("type", "MARKET");
        p.put("quantity", fmt(qty));
        p.put("newClientOrderId", clientId);
        p.put("newOrderRespType", "RESULT");
        return new JSONObject(request("POST", "/fapi/v1/order", p, true));
    }

    public JSONObject reduceOnlyMarket(String symbol, String side, double qty, String clientId) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", side);
        p.put("type", "MARKET");
        p.put("quantity", fmt(qty));
        p.put("reduceOnly", "true");
        p.put("newClientOrderId", clientId);
        p.put("newOrderRespType", "RESULT");
        return new JSONObject(request("POST", "/fapi/v1/order", p, true));
    }

    public JSONObject algoClose(String symbol, String side, String type, double triggerPrice,
                                String clientAlgoId) throws Exception {
        Map<String,String> p = new LinkedHashMap<>();
        p.put("algoType", "CONDITIONAL");
        p.put("symbol", symbol);
        p.put("side", side);
        p.put("positionSide", "BOTH");
        p.put("type", type);
        p.put("triggerPrice", fmt(triggerPrice));
        p.put("closePosition", "true");
        p.put("workingType", "MARK_PRICE");
        p.put("priceProtect", "true");
        p.put("clientAlgoId", clientAlgoId);
        return new JSONObject(request("POST", "/fapi/v1/algoOrder", p, true));
    }

    public void cancelAlgo(String clientAlgoId) {
        if (clientAlgoId == null || clientAlgoId.isEmpty()) return;
        try {
            Map<String,String> p = new LinkedHashMap<>();
            p.put("clientAlgoId", clientAlgoId);
            request("DELETE", "/fapi/v1/algoOrder", p, true);
        } catch (Exception ignored) {}
    }

    public static double floorStep(double x, double step) {
        if (step <= 0) return x;
        return Math.floor((x + 1e-12) / step) * step;
    }

    public static String fmt(double x) {
        return String.format(Locale.US, "%.12f", x)
                .replaceAll("0+$","").replaceAll("\\.$","");
    }
}
