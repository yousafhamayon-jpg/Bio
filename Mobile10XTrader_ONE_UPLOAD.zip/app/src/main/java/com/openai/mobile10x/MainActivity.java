package com.openai.mobile10x;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private Switch swLive;
    private EditText etApiKey, etSecret, etCapital, etLeverage, etRisk, etDailyLoss, etMinScore, etScanMinutes;
    private TextView tvMode, tvStatus, tvSignal, tvPosition, tvLog;
    private BotSettings settings;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            tvStatus.setText("Status: " + intent.getStringExtra(BotService.EXTRA_STATUS));
            String s = intent.getStringExtra(BotService.EXTRA_SIGNAL);
            if (s != null && !s.isEmpty()) tvSignal.setText(s);
            String p = intent.getStringExtra(BotService.EXTRA_POSITION);
            if (p != null && !p.isEmpty()) tvPosition.setText(p);
            String l = intent.getStringExtra(BotService.EXTRA_LOG);
            if (l != null) tvLog.setText(l);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(com.openai.mobile10x.R.layout.activity_main);
        settings = new BotSettings(this);

        swLive=findViewById(R.id.swLive);
        etApiKey=findViewById(R.id.etApiKey); etSecret=findViewById(R.id.etSecret);
        etCapital=findViewById(R.id.etCapital); etLeverage=findViewById(R.id.etLeverage);
        etRisk=findViewById(R.id.etRisk); etDailyLoss=findViewById(R.id.etDailyLoss);
        etMinScore=findViewById(R.id.etMinScore); etScanMinutes=findViewById(R.id.etScanMinutes);
        tvMode=findViewById(R.id.tvMode); tvStatus=findViewById(R.id.tvStatus);
        tvSignal=findViewById(R.id.tvSignal); tvPosition=findViewById(R.id.tvPosition);
        tvLog=findViewById(R.id.tvLog);

        loadUi();

        swLive.setOnCheckedChangeListener((buttonView, checked) -> {
            tvMode.setText(checked ? "MODE: LIVE — REAL MONEY" : "MODE: PAPER — NO MONEY");
            tvMode.setTextColor(checked ? 0xffB91C1C : 0xff047857);
        });

        findViewById(R.id.btnSave).setOnClickListener(v -> saveUi(false));
        findViewById(R.id.btnCheck).setOnClickListener(v -> checkConnection());
        findViewById(R.id.btnStart).setOnClickListener(v -> startRequested());
        findViewById(R.id.btnStop).setOnClickListener(v -> {
            stopService(new Intent(this, BotService.class));
            tvStatus.setText("Status: Stopped");
        });
        findViewById(R.id.btnEmergency).setOnClickListener(v -> emergencyClose());

        requestNotificationPermission();
    }

    private void loadUi() {
        swLive.setChecked(settings.live());
        etCapital.setText(String.valueOf(settings.capital()));
        etLeverage.setText(String.valueOf(settings.leverage()));
        etRisk.setText(String.valueOf(settings.riskPct()));
        etDailyLoss.setText(String.valueOf(settings.dailyLossPct()));
        etMinScore.setText(String.valueOf(settings.minScore()));
        etScanMinutes.setText(String.valueOf(settings.scanMinutes()));
        String key = settings.apiKey();
        etApiKey.setText(key.isEmpty() ? "" : key);
        // Do not put decrypted secret back on screen automatically.
        etSecret.setText("");
        tvMode.setText(settings.live() ? "MODE: LIVE — REAL MONEY" : "MODE: PAPER — NO MONEY");
        tvMode.setTextColor(settings.live() ? 0xffB91C1C : 0xff047857);
    }

    private boolean saveUi(boolean quiet) {
        try {
            double capital = Double.parseDouble(etCapital.getText().toString());
            int lev = Integer.parseInt(etLeverage.getText().toString());
            double risk = Double.parseDouble(etRisk.getText().toString());
            double daily = Double.parseDouble(etDailyLoss.getText().toString());
            int score = Integer.parseInt(etMinScore.getText().toString());
            int scan = Integer.parseInt(etScanMinutes.getText().toString());

            if (capital <= 0 || capital > 10000) throw new Exception("Bot capital is invalid.");
            if (lev < 1 || lev > 5) throw new Exception("This build limits leverage to 1–5x.");
            if (risk <= 0 || risk > 3) throw new Exception("Risk per trade must be 0–3%.");
            if (daily <= 0 || daily > 10) throw new Exception("Daily loss stop must be 0–10%.");
            if (score < 65 || score > 100) throw new Exception("Minimum score must be 65–100.");
            if (scan < 3 || scan > 60) throw new Exception("Scan interval must be 3–60 minutes.");

            settings.save(swLive.isChecked(), capital, lev, risk, daily, score, scan,
                    etApiKey.getText().toString(), etSecret.getText().toString());

            if (!quiet) Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Check settings").setMessage(e.getMessage())
                    .setPositiveButton("OK",null).show();
            return false;
        }
    }

    private void checkConnection() {
        if (!saveUi(true)) return;
        tvStatus.setText("Status: Checking...");
        io.execute(() -> {
            try {
                BinanceClient api = new BinanceClient(settings.apiKey(), settings.secret());
                api.exchangeRules();
                String msg = "Public Binance market data: OK";
                if (settings.live()) {
                    api.syncTime();
                    if (settings.apiKey().isEmpty() || settings.secret().isEmpty())
                        throw new Exception("LIVE mode needs API key and secret.");
                    if (api.hedgeMode()) throw new Exception("Hedge Mode is ON. This bot requires One-way Mode.");
                    double bal = api.usdtAvailableBalance();
                    msg += "\nPrivate Futures API: OK\nAvailable Futures USDT: " + BinanceClient.fmt(bal);
                }
                final String ok = msg;
                runOnUiThread(() -> {
                    tvStatus.setText("Status: Check passed");
                    new AlertDialog.Builder(this).setTitle("Connection OK").setMessage(ok)
                            .setPositiveButton("OK",null).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvStatus.setText("Status: Check failed");
                    new AlertDialog.Builder(this).setTitle("Connection failed").setMessage(e.getMessage())
                            .setPositiveButton("OK",null).show();
                });
            }
        });
    }

    private void startRequested() {
        if (!saveUi(true)) return;
        if (settings.live()) {
            if (settings.apiKey().isEmpty() || settings.secret().isEmpty()) {
                alert("LIVE mode needs Binance API key and secret.");
                return;
            }
            final EditText input = new EditText(this);
            input.setHint("Type LIVE");
            input.setInputType(InputType.TYPE_CLASS_TEXT);
            new AlertDialog.Builder(this)
                    .setTitle("Real-money confirmation")
                    .setMessage("This can place real Binance Futures trades. API withdrawals should be DISABLED. The bot uses its software capital cap, isolated margin, one position and mandatory SL/TP.\n\nType LIVE to continue.")
                    .setView(input)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Continue", (d,w) -> {
                        if (!"LIVE".equals(input.getText().toString().trim())) {
                            alert("Not started. You must type LIVE exactly.");
                            return;
                        }
                        startBot();
                    }).show();
        } else {
            startBot();
        }
    }

    private void startBot() {
        Intent i = new Intent(this, BotService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        tvStatus.setText("Status: Starting...");
        suggestBatteryExemption();
    }

    private void emergencyClose() {
        if (!saveUi(true)) return;
        new AlertDialog.Builder(this)
                .setTitle("Emergency close")
                .setMessage("Close only the trade stored by this bot?")
                .setNegativeButton("Cancel",null)
                .setPositiveButton("CLOSE", (d,w) -> io.execute(() -> {
                    try {
                        BinanceClient api = new BinanceClient(settings.apiKey(), settings.secret());
                        TradeManager tm = new TradeManager(api, settings,
                                text -> runOnUiThread(() -> tvLog.append("\n"+text)));
                        tm.emergencyClose();
                        runOnUiThread(() -> {
                            tvPosition.setText("Bot position: None");
                            Toast.makeText(this,"Emergency close sent.",Toast.LENGTH_LONG).show();
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> alert(e.getMessage()));
                    }
                })).show();
    }

    private void suggestBatteryExemption() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception ignored) {}
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    private void alert(String s) {
        new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter(BotService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
    }

    @Override protected void onStop() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onStop();
    }
}
