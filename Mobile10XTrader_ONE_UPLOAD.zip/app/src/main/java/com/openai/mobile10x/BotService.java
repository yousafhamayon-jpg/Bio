package com.openai.mobile10x;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class BotService extends Service {
    public static final String ACTION_STATUS = "com.openai.mobile10x.STATUS";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_SIGNAL = "signal";
    public static final String EXTRA_POSITION = "position";
    public static final String EXTRA_LOG = "log";
    private static final int NOTIF_ID = 1010;
    private static final String CHANNEL = "mobile10x_bot";

    private ScheduledExecutorService scheduler;
    private volatile boolean busy = false;
    private BotSettings settings;
    private StringBuilder recentLog = new StringBuilder();

    public interface LogSink { void log(String text); }

    private final LogSink sink = text -> {
        String ts = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        synchronized (recentLog) {
            recentLog.append("[").append(ts).append("] ").append(text).append("\n");
            if (recentLog.length() > 9000) recentLog.delete(0, 3000);
        }
        broadcast("Running", "", currentPositionText(), text);
    };

    @Override
    public void onCreate() {
        super.onCreate();
        settings = new BotSettings(this);
        createChannel();
        startForeground(NOTIF_ID, notification("Bot running • " + (settings.live() ? "LIVE" : "PAPER")));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (scheduler != null) scheduler.shutdownNow();
        scheduler = Executors.newSingleThreadScheduledExecutor();
        long minutes = settings.scanMinutes();
        scheduler.scheduleWithFixedDelay(this::cycleSafe, 0, minutes, TimeUnit.MINUTES);
        return START_STICKY;
    }

    private void cycleSafe() {
        if (busy) return;
        busy = true;
        PowerManager.WakeLock wl = null;
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Mobile10X:scan");
            wl.acquire(120_000);

            BinanceClient api = new BinanceClient(settings.apiKey(), settings.secret());
            TradeManager tm = new TradeManager(api, settings, sink);

            if (settings.hasActiveTrade()) {
                tm.monitorActive();
                broadcast("Managing active trade", "", currentPositionText(), "");
                return;
            }

            if (!tm.dailyRiskAllows()) {
                broadcast("Risk stop active", "NO TRADE", "Bot position: None", "");
                return;
            }

            if (settings.live()) api.syncTime();

            Map<String,BinanceClient.SymbolRules> rules = api.exchangeRules();
            SignalEngine engine = new SignalEngine(api);
            sink.log("Starting 10X scan...");
            SignalEngine.Signal signal = engine.scan(rules, settings.minScore(), sink);

            if (signal == null) {
                sink.log("NO TRADE: no setup met the minimum score.");
                broadcast("Waiting", "Signal: NO TRADE", "Bot position: None", "");
                return;
            }

            String signalText = "Signal: " + signal.side + " " + signal.symbol +
                    " | score " + signal.score +
                    " | entry≈" + BinanceClient.fmt(signal.entry) +
                    " | SL " + BinanceClient.fmt(signal.stop) +
                    " | TP " + BinanceClient.fmt(signal.target);

            broadcast("High-conviction setup found", signalText, "Bot position: None", "");
            sink.log(signal.explanation);
            tm.open(signal, rules);
            broadcast("Trade active", signalText, currentPositionText(), "");

        } catch (Exception e) {
            sink.log("ERROR: " + e.getMessage());
            broadcast("Error", "", currentPositionText(), e.getMessage());
        } finally {
            if (wl != null && wl.isHeld()) wl.release();
            busy = false;
        }
    }

    private String currentPositionText() {
        if (!settings.hasActiveTrade()) return "Bot position: None";
        return "Bot position: " + settings.activeSide() + " " + settings.activeSymbol() +
                " | entry " + BinanceClient.fmt(settings.activeEntry()) +
                " | SL " + BinanceClient.fmt(settings.activeStop()) +
                " | TP " + BinanceClient.fmt(settings.activeTarget());
    }

    private void broadcast(String status, String signal, String position, String lastLine) {
        Intent i = new Intent(ACTION_STATUS);
        i.setPackage(getPackageName());
        i.putExtra(EXTRA_STATUS, status);
        i.putExtra(EXTRA_SIGNAL, signal);
        i.putExtra(EXTRA_POSITION, position);
        synchronized (recentLog) {
            i.putExtra(EXTRA_LOG, recentLog.toString());
        }
        sendBroadcast(i);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "Mobile 10X Trader", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Keeps the trading bot running while the screen is off.");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setContentTitle("Mobile 10X Trader")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
