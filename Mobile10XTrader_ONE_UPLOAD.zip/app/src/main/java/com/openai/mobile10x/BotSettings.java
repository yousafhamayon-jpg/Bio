package com.openai.mobile10x;

import android.content.Context;
import android.content.SharedPreferences;

public class BotSettings {
    private static final String PREF = "mobile10x_settings";
    private final SharedPreferences p;
    private final SecureStore secure;

    public BotSettings(Context c) {
        p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        secure = new SecureStore(c);
    }

    public void save(boolean live, double capital, int leverage, double riskPct,
                     double dailyLossPct, int minScore, int scanMinutes,
                     String apiKey, String secret) {
        p.edit()
                .putBoolean("live", live)
                .putFloat("capital", (float) capital)
                .putInt("leverage", leverage)
                .putFloat("riskPct", (float) riskPct)
                .putFloat("dailyLossPct", (float) dailyLossPct)
                .putInt("minScore", minScore)
                .putInt("scanMinutes", scanMinutes)
                .apply();
        if (apiKey != null && !apiKey.isEmpty()) secure.put("apiKey", apiKey.trim());
        if (secret != null && !secret.isEmpty()) secure.put("secret", secret.trim());
    }

    public boolean live() { return p.getBoolean("live", false); }
    public double capital() { return p.getFloat("capital", 10f); }
    public int leverage() { return Math.max(1, Math.min(5, p.getInt("leverage", 3))); }
    public double riskPct() { return p.getFloat("riskPct", 1.5f); }
    public double dailyLossPct() { return p.getFloat("dailyLossPct", 5f); }
    public int minScore() { return p.getInt("minScore", 75); }
    public int scanMinutes() { return Math.max(3, p.getInt("scanMinutes", 5)); }
    public String apiKey() { return secure.get("apiKey"); }
    public String secret() { return secure.get("secret"); }

    public long dayKey() {
        return System.currentTimeMillis() / 86_400_000L;
    }

    public double dailyPnl() {
        long dk = p.getLong("pnlDay", -1);
        if (dk != dayKey()) {
            p.edit().putLong("pnlDay", dayKey()).putFloat("dailyPnl", 0f)
                    .putInt("lossCount", 0).apply();
            return 0;
        }
        return p.getFloat("dailyPnl", 0f);
    }

    public int lossCount() {
        dailyPnl();
        return p.getInt("lossCount", 0);
    }

    public void recordPnl(double pnl) {
        double now = dailyPnl() + pnl;
        int losses = lossCount() + (pnl < 0 ? 1 : 0);
        p.edit().putLong("pnlDay", dayKey()).putFloat("dailyPnl", (float) now)
                .putInt("lossCount", losses).apply();
    }

    public long lastLossTime() { return p.getLong("lastLossTime", 0); }
    public void markLossTime() { p.edit().putLong("lastLossTime", System.currentTimeMillis()).apply(); }

    public void setActiveTrade(String symbol, String side, double qty, double entry,
                               double stop, double target, String slId, String tpId, boolean paper) {
        p.edit()
                .putString("activeSymbol", symbol)
                .putString("activeSide", side)
                .putFloat("activeQty", (float) qty)
                .putFloat("activeEntry", (float) entry)
                .putFloat("activeStop", (float) stop)
                .putFloat("activeTarget", (float) target)
                .putString("activeSlId", slId == null ? "" : slId)
                .putString("activeTpId", tpId == null ? "" : tpId)
                .putBoolean("activePaper", paper)
                .apply();
    }

    public boolean hasActiveTrade() {
        return !p.getString("activeSymbol", "").isEmpty();
    }

    public String activeSymbol() { return p.getString("activeSymbol", ""); }
    public String activeSide() { return p.getString("activeSide", ""); }
    public double activeQty() { return p.getFloat("activeQty", 0f); }
    public double activeEntry() { return p.getFloat("activeEntry", 0f); }
    public double activeStop() { return p.getFloat("activeStop", 0f); }
    public double activeTarget() { return p.getFloat("activeTarget", 0f); }
    public String activeSlId() { return p.getString("activeSlId", ""); }
    public String activeTpId() { return p.getString("activeTpId", ""); }
    public boolean activePaper() { return p.getBoolean("activePaper", true); }

    public void clearActiveTrade() {
        p.edit()
                .remove("activeSymbol").remove("activeSide").remove("activeQty")
                .remove("activeEntry").remove("activeStop").remove("activeTarget")
                .remove("activeSlId").remove("activeTpId").remove("activePaper")
                .apply();
    }
}
